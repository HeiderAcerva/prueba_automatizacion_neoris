# Instrucciones de Ejecución del Flujo de Compra con Cypress

Este repositorio contiene código en JavaScript que simula un flujo de compra de productos utilizando Cypress. A continuación, se detallan los pasos para entender y ejecutar el flujo de compra:

## Pasos Previos

1. **Instalar Cypress**: Asegúrate de tener Cypress instalado en tu sistema. Puedes encontrar instrucciones de instalación en la documentación oficial de Cypress: [Instalación de Cypress](https://docs.cypress.io/guides/getting-started/installing-cypress.html)

2. **Clonar el Repositorio**: Clona este repositorio en tu máquina local.

## Descripción del Código

El código está organizado en clases que representan diferentes partes del flujo de compra. A continuación se describen las clases y sus funciones:

1. **Authentication**: Esta clase se encarga de autenticar al usuario en el sitio web de prueba.
2. **CartPage**: Esta clase representa la página del carro de compras y contiene la función para proceder al checkout.
3. **CheckoutPage**: Aquí se completa el formulario de compra, se continúa con el proceso y se finaliza la compra.
4. **ProductsPage**: En esta clase se pueden agregar productos al carro de compras.

La clase principal `Purchase Flow` invoca los métodos de las clases mencionadas anteriormente para simular el flujo de compra.

## Ejecución del Código

Una vez que hayas instalado Cypress y clonado el repositorio, sigue estos pasos para ejecutar el flujo de compra:

1. **Abrir Cypress**: Abre la terminal en la carpeta raíz del repositorio clonado y ejecuta el comando `npx cypress open`.

2. **Seleccionar el Archivo de Pruebas**: En la interfaz de Cypress, selecciona el archivo `purchase_flow.spec.js` para ejecutar las pruebas.

3. **Observar la Ejecución**: Cypress abrirá un navegador y ejecutará el flujo de compra de manera automatizada. Podrás ver las interacciones en el navegador y los resultados de las pruebas en la interfaz de Cypress.

4. **Revisar Resultados**: Una vez finalizada la ejecución, puedes revisar los resultados de las pruebas en la interfaz de Cypress y también encontrarás capturas de pantalla de la ejecución en la carpeta `screenshots` del repositorio.

¡Y eso es todo! Ahora estás listo para entender y ejecutar el flujo de compra utilizando Cypress.