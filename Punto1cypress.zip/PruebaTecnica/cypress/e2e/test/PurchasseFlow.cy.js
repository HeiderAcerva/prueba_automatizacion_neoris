import Authentication from "../Pages/Authentication.cy"
import CartPage from "../Pages/CartPage.cy"
import ProductsPage from "../Pages/ProductsPage.cy"
import CheckoutPage from "../Pages/CheckoutPage.cy"


describe('Purchase Flow', () => {
    it('should complete a purchase', () => {
        const auth = new Authentication()
        const products = new ProductsPage()
        const cartPage = new CartPage()
        const checkoutPage = new CheckoutPage()
    

        // 1. Autenticar al cliente
        auth.vis()
        auth.fillUsername('standard_user')
        auth.fillPassword('secret_sauce')
        auth.loginclick()

        // Aserción para validar que estamos en la página de productos
        cy.url().should('include', '/inventory.html')

        // 2. Agregar dos productos al carro de compras
        products.addProduct('Sauce Labs Backpack')
        products.addProduct('Sauce Labs Bike Light')

        // 3. Visualizar el carro de compras
        products.clickAddToCartButton()

        // Aserción para validar que los dos productos están en el carro de compras
        cy.get('.cart_item').should('have.length', 2)

        // 4. Completar el formulario de compra
        cartPage.checkout()
        checkoutPage.fillForm()
        checkoutPage.continue()

        // 5. Finalizar la compra hasta la confirmación
        checkoutPage.finish()
        checkoutPage.confirmOrder()
        
        //6. ScreenShot
        checkoutPage.validatePurchase()

    })
})