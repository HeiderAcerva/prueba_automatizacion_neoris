class ProductsPage {
    addProduct(productName) {
       cy.contains('.inventory_item_description', productName).parent().find('.btn_inventory').click()
       
    }
    clickAddToCartButton() {
        cy.get('.shopping_cart_link').click()
        cy.wait(3000)
    }
  }
  
  export default ProductsPage