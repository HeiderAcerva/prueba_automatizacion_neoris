class CartPage {
    checkout() {
        cy.get('.checkout_button').click()
    }
  }
  
  export default CartPage
