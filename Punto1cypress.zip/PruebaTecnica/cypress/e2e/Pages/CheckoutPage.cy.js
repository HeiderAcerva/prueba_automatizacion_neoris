/// <reference types="Cypress" />

require('cypress-plugin-tab')

class CheckoutPage {
    fillForm(value) {
        cy.get('[data-test=firstName]').type("Heider").tab()
        .type("Cervantes").tab()
        .type("111012")
    }


    continue() {
        cy.get('.cart_button').click()
    }

    finish() {
        cy.get('.cart_button').click()
    }

    confirmOrder() {
        cy.get('.complete-header').should('have.text', 'Thank you for your order!')

    }
    
    validatePurchase() {
        cy.contains('Thank you for your order!').then((elemento1) => {
          if (elemento1.is(':visible')) {
            cy.screenshot();
          } else {
            throw new Error('Thank you message not visible.');
          }

        })}


}

export default CheckoutPage