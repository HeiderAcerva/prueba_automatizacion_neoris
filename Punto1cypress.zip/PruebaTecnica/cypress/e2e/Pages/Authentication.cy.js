class Authentication {
    vis() {
        
     cy.visit('https://www.saucedemo.com/')
     
    }
  
    fillUsername(value) {
  
        cy.get("#user-name").type(value)
        
    }
  
    fillPassword(value) {
        cy.get("#password").type(value)
        
    }
  
    loginclick() {
        cy.get('#login-button').click()
    
    }
  }
  export default Authentication
